// app/admin/alunas/loading.tsx
export default function Loading() {
  return null
}
