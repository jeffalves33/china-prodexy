// app/admin/professoras/loading.tsx
export default function Loading() {
  return null
}
